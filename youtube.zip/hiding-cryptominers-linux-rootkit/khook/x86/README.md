KHOOK x86 stub generator, use `make` to (re)-generate.
